
package inventorymanagement;
import java.util.Arrays;

public class Product2 {

   
    static class Product 
    {
        private String productId;
        private String productName;
        private String category;

     
        public Product(String productId, String productName, String category) 
        {
            this.productId = productId;
            this.productName = productName;
            this.category = category;
        }

        
        public String getProductId() 
        {
        	return productId; 
        }
        public String getProductName() 
        { 
        	return productName; 
        }
        public String getCategory() 
        {
        	return category; 
        }

      
        public String toString() 
        {
            return "Product{" + "productId='" + productId + '\'' + ", productName='" + productName + '\'' + ", category='" + category + '\'' + '}';
        }
    }

    
    public static Product linearSearch(Product[] products, String searchTerm) {
        for (Product product : products) {
            if (product.getProductId().equals(searchTerm) ||
                product.getProductName().equalsIgnoreCase(searchTerm) ||
                product.getCategory().equalsIgnoreCase(searchTerm)) {
                return product;
            }
        }
        return null; 
    }

    
    public static Product binarySearch(Product[] products, String searchTerm) {
        int left = 0;
        int right = products.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            Product midProduct = products[mid];
            
            
            int comparison = searchTerm.compareTo(midProduct.getProductId());
            if (comparison == 0) {
                return midProduct;
            } else if (comparison < 0) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        return null;
    }

    
    public static void main(String[] args) {
        
        Product[] products = {
            new Product("P2", "Smartwatch", "Electronics"),
            new Product("P1", "Laptop", "Computers"),
            new Product("P3", "Earphones", "Accessories"),
            new Product("P4", "Television","Electronics")
        };

        
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        
        System.out.println("Testing Linear Search:");
        Product linearSearch = linearSearch(products, "Smartwatch");
        System.out.println("Linear Search Result: " + linearSearch);

        
        System.out.println("\nTesting Binary Search:");
        Product BinarySearch = binarySearch(products, "P3");
        System.out.println("Binary Search Result: " + BinarySearch);
        
        
        Product NotFound = binarySearch(products, "P7");
        System.out.println("Binary Search Result for Non-existent Product: " + NotFound);
    }
}

package inventorymanagement;

import java.util.Arrays;

public class Employee {

    
        private int employeeId;
        private String name;
        private String position;
        private double salary;

        public Employee(int employeeId, String name, String position, double salary) {
            this.employeeId = employeeId;
            this.name = name;
            this.position = position;
            this.salary = salary;
        }

        public int getEmployeeId() {
            return employeeId;
        }

        public String getName() {
            return name;
        }

        public String getPosition() {
            return position;
        }

        public double getSalary() {
            return salary;
        }

       
        public String toString() {
            return "Employee{id=" + employeeId + ", name='" + name + "', position='" + position + "', salary=" + salary + "}";
        }
    

    
    private Employee[] employees;
    private int size;
    private int capacity;

    public Employee(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

   
    public boolean addEmployee(Employee employee) {
        if (size == capacity) {
            capacity *= 2;
            employees = Arrays.copyOf(employees, capacity);
        }

        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employee.getEmployeeId()) {
                System.out.println("Employee with ID " + employee.getEmployeeId() + " already exists.");
                return false;
            }
        }

        employees[size++] = employee;
        return true;
    }

    
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    
    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                employees[i] = employees[size - 1];
                employees[size - 1] = null;
                size--;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Employee system = new Employee(2);

      
        boolean added1 = system.addEmployee(new Employee(1, "Ananya", "Manager", 95000));
        boolean added2 = system.addEmployee(new Employee(2, "Vidya", "Engineer", 50000));
        boolean added3 = system.addEmployee(new Employee(3, "Chinmay", "Associate", 35000));
        boolean added4 = system.addEmployee(new Employee(2, "Priya", "Engineer", 60000)); 
        boolean added5 = system.addEmployee(new Employee(2, "Venky", "Engineer", 80000)); 

        System.out.println("Add Employee Results:");
        System.out.println("Employee 1 added: " + added1);
        System.out.println("Employee 2 added: " + added2);
        System.out.println("Employee 3 added: " + added3);
        System.out.println("Employee 4 added: " + added4);  
        System.out.println("Employee 5 added: " + added5); 

        
        System.out.println("\nAll Employees:");
        system.traverseEmployees();

        
        int searchId = 2;
        Employee found = system.searchEmployee(searchId);
        System.out.println("\nSearch Result for ID " + searchId + ": " + found);

       
        int deleteId = 2;
        boolean deleted = system.deleteEmployee(deleteId);
        System.out.println("\nDelete Employee with ID " + deleteId + ": " + (deleted ? "Success" : "Failure"));

 
        System.out.println("\nAll Employees after Deletion:");
        system.traverseEmployees();
    }
}
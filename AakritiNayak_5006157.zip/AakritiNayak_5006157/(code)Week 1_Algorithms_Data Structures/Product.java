
package inventorymanagement;

import java.util.HashMap;
import java.util.Map;

public class Product {

    

        private int productId;
        private String productName;
        private int quantity;
        private double price;

        public Product(int productId, String productName, int quantity, double price)
        {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        public int getProductId() 
        {
            return productId;
        }

        public String getProductName()
        {
            return productName;
        }

        public int getQuantity()
        {
            return quantity;
        }

        public double getPrice() 
        {
            return price;
        }

        public void setQuantity(int quantity) 
        {
            this.quantity = quantity;
        }

        public void setPrice(double price)
        {
            this.price = price;
        }

       
        public String toString() {
            return "Product{id=" + productId + ", name='" + productName + "', quantity=" + quantity + ", price=" + price + "}";
        }
    

    private Map<Integer, Product> inventory;

    public Product() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " existing.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " product added to inventory.");
        }
    }

    public void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + "product updated in inventory.");
        } else {
            System.out.println("Product with ID " + product.getProductId() + " does not exist.");
        }
    }

    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
            System.out.println("Product with ID " + productId + "product deleted from inventory.");
        } else {
            System.out.println("Product with ID " + productId + " product does not exist.");
        }
    }

    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Product s = new Product();

       
        Product product1 = new Product(1, "Refrigerator", 10, 8);
        Product product2 = new Product(2, "Smartphone", 50, 16000);
        Product product3 = new Product(2, "watch", 60, 400); 
        
        s.addProduct(product1);
        s.addProduct(product2);
        s.addProduct(product3);
       
        Product product1Updated = new Product(1, "Refrigerator", 15, 100000.99);
        s.updateProduct(product1Updated);

       
        s.deleteProduct(2);

       
        s.displayInventory();
    }
}


package inventorymanagement;

public class Task {

    
   
        private int taskId;
        private String taskName;
        private String status;

        public Task(int taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
        }

        public Task() {
			
		}

		public int getTaskId() {
            return taskId;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getStatus() {
            return status;
        }

        
        public String toString() {
            return "Task{id=" + taskId + ", name='" + taskName + "', status='" + status + "'}";
        }

		public void addTask(Task task) {
		
			
		}

		public void traverseTasks() {
			
			
		}

		public Task searchTask(int searchId) {
			
			return null;
		}

		public boolean deleteTask(int deleteId) {
		
			return false;
		}
    }

    
    class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    

    
    private Node head;
    private int size;

    public void Task() {
        this.head = null;
        this.setSize(0);
    }

   
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        setSize(getSize() + 1);
    }

    
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    
    public boolean deleteTask(int taskId) {
        if (head == null) {
            return false;
        }
        if (head.task.getTaskId() == taskId) {
            head = head.next;
            setSize(getSize() - 1);
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId() == taskId) {
                current.next = current.next.next;
                setSize(getSize() - 1);
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public static void main(String[] args) {
        Task system = new Task();

       
        system.addTask(new Task(1, "1", "Pending"));
        system.addTask(new Task(2, "2", "In Progress"));
        system.addTask(new Task(3, "3", "Completed"));

        
        System.out.println("All Tasks:");
        system.traverseTasks();

        
        int searchId = 2;
        Task found = system.searchTask(searchId);
        System.out.println("\nSearch Result for ID " + searchId + ": " + found);

       
        int deleteId = 2;
        boolean deleted = system.deleteTask(deleteId);
        System.out.println("\nDelete Task with ID " + deleteId + ": " + (deleted ? "Success" : "Failure"));

        
        System.out.println("\nAll Tasks after Deletion:");
        system.traverseTasks();
    }

	public int getSize() 
	{
		return size;
	}

	public void setSize(int size) 
	{
		this.size = size;
	}
}

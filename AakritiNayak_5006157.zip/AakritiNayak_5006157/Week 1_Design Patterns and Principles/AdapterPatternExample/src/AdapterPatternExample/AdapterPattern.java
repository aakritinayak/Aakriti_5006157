package AdapterPatternExample;

public class AdapterPattern
{

    public interface PaymentProcessor 
    {
        void processPayment(double amount);
    }

    public static class StripePaymentGateway 
    {
        public void charge(double amount) 
        {
            System.out.println("Charging $" + amount + " through Stripe.");
        }
    }

    public static class PayPalPaymentGateway 
    {
        public void makePayment(double amount) 
        {
            System.out.println("Making payment of $" + amount + " through PayPal.");
        }
    }

    public static class StripeAdapter implements PaymentProcessor 
    {
        private StripePaymentGateway stripePaymentGateway;

        public StripeAdapter(StripePaymentGateway stripePaymentGateway) 
        {
            this.stripePaymentGateway = stripePaymentGateway;
        }

        
        public void processPayment(double amount) 
        {
            stripePaymentGateway.charge(amount);
        }
    }

    public static class PayPalAdapter implements PaymentProcessor 
    {
        private PayPalPaymentGateway payPalPaymentGateway;

        public PayPalAdapter(PayPalPaymentGateway payPalPaymentGateway) 
        {
            this.payPalPaymentGateway = payPalPaymentGateway;
        }

       
        public void processPayment(double amount) 
        {
            payPalPaymentGateway.makePayment(amount);
        }
    }

    public static void main(String[] args) {
        PaymentProcessor stripeProcessor = new StripeAdapter(new StripePaymentGateway());
        PaymentProcessor payPalProcessor = new PayPalAdapter(new PayPalPaymentGateway());

        stripeProcessor.processPayment(150.0);
        payPalProcessor.processPayment(200.0);
    }
}

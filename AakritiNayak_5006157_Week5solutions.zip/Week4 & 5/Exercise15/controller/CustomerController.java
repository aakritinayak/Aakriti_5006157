package com.book.controller;

import com.book.dto.CustomerDTO;
import com.book.assembler.CustomerResourceAssembler;
import com.book.model.Customer;
import com.book.services.CustomerService;
import com.book.mapper.CustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CustomerMapper customerMapper;

    @Autowired
    private CustomerResourceAssembler customerResourceAssembler;

    @PostMapping
    public ResponseEntity<EntityModel<CustomerDTO>> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = customerMapper.customerDTOToCustomer(customerDTO);
        Customer savedCustomer = customerService.saveCustomer(customer);
        CustomerDTO savedCustomerDTO = customerMapper.customerToCustomerDTO(savedCustomer);
        EntityModel<CustomerDTO> resource = customerResourceAssembler.toModel(savedCustomerDTO);
        return new ResponseEntity<>(resource, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.findCustomerById(id);
        CustomerDTO customerDTO = customerMapper.customerToCustomerDTO(customer);
        EntityModel<CustomerDTO> resource = customerResourceAssembler.toModel(customerDTO);
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<EntityModel<CustomerDTO>>> getAllCustomers() {
        List<Customer> customers = customerService.findAllCustomers();
        List<EntityModel<CustomerDTO>> customerResources = customers.stream()
                .map(customer -> customerMapper.customerToCustomerDTO(customer))
                .map(customerDTO -> customerResourceAssembler.toModel(customerDTO))
                .collect(Collectors.toList());
        return new ResponseEntity<>(customerResources, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> updateCustomer(@PathVariable Long id, @Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = customerMapper.customerDTOToCustomer(customerDTO);
        Customer updatedCustomer = customerService.updateCustomer(id, customer);
        CustomerDTO updatedCustomerDTO = customerMapper.customerToCustomerDTO(updatedCustomer);
        EntityModel<CustomerDTO> resource = customerResourceAssembler.toModel(updatedCustomerDTO);
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

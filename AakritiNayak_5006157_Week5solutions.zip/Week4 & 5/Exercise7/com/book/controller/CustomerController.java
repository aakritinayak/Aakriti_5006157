package com.book.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.book.dto.CustomerDTO;
import com.book.mapper.CustomerMapper;
import com.book.model.Customer;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    private List<Customer> customers = new ArrayList<>(); // This is just for example; normally, you'd use a service

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        Customer customer = customers.stream()
            .filter(c -> c.getId().equals(id))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Customer not found"));
        return new ResponseEntity<>(customerMapper.customerToCustomerDTO(customer), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
        Customer customer = customerMapper.customerDTOToCustomer(customerDTO);
        customers.add(customer);
        return new ResponseEntity<>(customerMapper.customerToCustomerDTO(customer), HttpStatus.CREATED);
    }

    
}


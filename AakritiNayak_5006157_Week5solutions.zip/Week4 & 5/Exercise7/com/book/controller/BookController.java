package com.book.controller;

import com.book.dto.BookDTO;
import com.book.exception.BookNotFoundException;
import com.book.mapper.BookMapper;
import com.book.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;

@RestController
@RequestMapping("/books")
public class BookController {

    private ModelMapper modelMapper = new ModelMapper();

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = findBookById(id);
        BookDTO bookDTO = modelMapper.map(book, BookDTO.class);
        return new ResponseEntity<>(bookDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        Book book = modelMapper.map(bookDTO, Book.class);
        saveBook(book);
        return new ResponseEntity<>(modelMapper.map(book, BookDTO.class), HttpStatus.CREATED);
    }
}

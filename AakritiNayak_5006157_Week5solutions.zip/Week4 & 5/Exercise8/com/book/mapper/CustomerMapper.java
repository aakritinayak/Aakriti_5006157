package com.book.mapper;

import com.book.dto.CustomerDTO;
import com.book.model.Customer;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CustomerMapper {
    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

    CustomerDTO customerToCustomerDTO(Customer customer);
    List<CustomerDTO> customerToCustomerDTO(List<Customer> customers);
    Customer customerDTOToCustomer(CustomerDTO customerDTO);
}

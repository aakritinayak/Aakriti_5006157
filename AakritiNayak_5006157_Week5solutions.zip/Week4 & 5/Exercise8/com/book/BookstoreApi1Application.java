package com.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApi1Application.class, args);
	}

}

package com.book.repository;

import static org.assertj.core.api.Assertions.assertThat;

import com.book.model.Book;
import com.book.repository.BookRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class BookRepositoryIntegrationTest {

    @Autowired
    private BookRepository bookRepository;

    @Test
    public void testSaveBook() {
        Book book = new Book(null, "Effective Java", "Joshua Bloch", 45.00, "9780134685991");
        Book savedBook = bookRepository.save(book);

        assertThat(savedBook).isNotNull();
        assertThat(savedBook.getId()).isNotNull();
        assertThat(savedBook.getTitle()).isEqualTo("Effective Java");
    }

    @Test
    public void testFindBookById() {
        Book book = new Book(null, "Effective Java", "Joshua Bloch", 45.00, "9780134685991");
        Book savedBook = bookRepository.save(book);

        Book foundBook = bookRepository.findById(savedBook.getId()).orElse(null);
        assertThat(foundBook).isNotNull();
        assertThat(foundBook.getTitle()).isEqualTo("Effective Java");
    }
}


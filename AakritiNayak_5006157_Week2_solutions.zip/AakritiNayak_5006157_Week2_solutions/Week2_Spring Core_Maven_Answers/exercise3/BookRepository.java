package com.library.repository;

public class BookRepository {
    // Repository methods
}

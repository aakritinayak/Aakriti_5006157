package com.book.controller;

import com.book.exception.BookNotFoundException;
import com.book.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookMapper bookMapper = BookMapper.INSTANCE;

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = findBookById(id); // Assume this method fetches the book entity
        BookDTO bookDTO = bookMapper.bookToBookDTO(book);
        return new ResponseEntity<>(bookDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        saveBook(book); // Assume this method saves the book entity
        return new ResponseEntity<>(bookMapper.bookToBookDTO(book), HttpStatus.CREATED);
    }
}
